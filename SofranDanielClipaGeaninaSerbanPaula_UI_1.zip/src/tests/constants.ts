
export const BASE_URL= 'http://qa1.dev.evozon.com/'